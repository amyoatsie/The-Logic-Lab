import tkinter as tk
from pathlib import Path
import ttkbootstrap as ttk # type: ignore

# Import screens
from screens.home_screen import HomeScreen
from screens.case_one import ChallengeScreenOne

HEADING_FONT = "Arial Black" # Used "Arial Black" as an Archivo alternative as they have similar weights
BODY_FONT = "Roboto" # Main text font defined as a constant
WINDOW_WIDTH = 1366
WINDOW_HEIGHT = 768

class App(ttk.Window): # Allow the main application controller to inherit directly from ttk.Window instead of standard tk.Tk
    # Responsible for creating the application window, loading the global theme, storing shared application data, navigating between screens
    def __init__(self):
        super().__init__(title="User Module Access", size=(WINDOW_WIDTH, WINDOW_HEIGHT))

        self.current_user = None

        # Variables defined inside app class, therefore references as "app.___"
        self.base_dir = Path(__file__).resolve().parent #references the "relative folder"!!!
        self.data_dir = self.base_dir / "data" #act like global variables but are only defined once

        self.setup_custom_theme() # injects global style engine profile

        # define repos ???
        # e.g. self.challenge_repo = ChallengeRepoCsv(self.data_dir / "progress.csv")

        # Define Navigation Container (Where screens swap out) !!!
        self.container = ttk.Frame(self) # in case future errors occur, ttk could be change to tb which is a more universal abbreviation
        self.container.pack(fill="both", expand=True)
        self.current_screen = None
        self.show_screen(HomeScreen)

        # Initialise initial screen display !!! change to homescreen when created!
        '''self.current_screen = ChallengeScreenOne(self.container)
        self.current_screen.pack(fill="both", expand=True)'''

    #----------------------------------------------------------------------------

    def setup_custom_theme(self): # Custom colouring is defined to match the mockups in a method
        # Create and apply the global color set application-wide
        style = ttk.Style()
        custom_colours = {
            'primary': '#46403A',
            'secondary': '#D7C4AC',
            'success': "#61daae", 
            'info': '#A2B9CB', # same as border
            'warning': '#f6c23e', # might not need to change?
            'danger': '#B3261E',
            'light': '#FFF6EB',
            'dark': '#5a5c69', # have yet to change
            'bg': '#C1A37F',
            'fg': '#2e2f37', # have yet to change, text colour (fg)
            'selectbg': '#eaecf4', # have yet to change
            'selectfg': "#ffffff", # front 
            'border': '#A2B9CB',
            'inputfg': '#2e2f37', # have yet to change
            'inputbg': '#CAB8A2',
            'active': '#dddfeb' # have yet to change
            }
        
        #style.theme_names().append('logic_lab_theme')
        style.theme_use('flatly') # Set a standard base theme style to safely map basic window behaviors !!!        
        # Override the colors in memory instantly using the official settings setter
        for color_name, hex_code in custom_colours.items():
            style.colors.set(color_name, hex_code)

        BG_COLOR = custom_colours['bg']

    #----------------------------------------------------------------------------

        # Heading 1 (The main header)
        style.configure('H1.TLabel', font=(HEADING_FONT, -48), foreground=custom_colours['primary'], 
                        background=BG_COLOR)
        # Heading 2 (The question numbers)
        style.configure('H2.TLabel', font=(BODY_FONT, -24), foreground=custom_colours['primary'], 
                        background=custom_colours['secondary'])
        # Heading 3 (The menu sub-headings and the questions)
        style.configure('H3.TLabel', font=(BODY_FONT, -18), foreground=custom_colours['primary'], 
                        background=custom_colours['secondary'])
        # Heading 4 (The user inputs and main answers) !!!
        style.configure('H4.TLabel', font=(BODY_FONT, -16), foreground=custom_colours['primary'], 
                        background=BG_COLOR)
        # Heading 5 (The explanatory text)
        style.configure('H5.TLabel', font=(BODY_FONT, -14), foreground=custom_colours['primary'], 
                        background=BG_COLOR)
        # Heading 6 (Buttons)
        style.configure('H6.TButton', font=(BODY_FONT, -16), foreground=style.colors.light, 
                        background=style.colors.primary, bordercolor=style.colors.border, 
                        focuscolor=style.colors.border)
        style.map('H6.TButton', foreground=[('active', style.colors.light)], background=[('active', style.colors.info)])

        # Heading 2 (The question header)
        style.configure('H2-2.TLabel', font=(HEADING_FONT, -24), foreground=custom_colours['primary'], 
                        background=BG_COLOR)

    #----------------------------------------------------------------------------

        # Home screen specific fonts
        style.configure('HS2.TLabel', font=(HEADING_FONT, -20), foreground=custom_colours['primary'], 
                        background=custom_colours['secondary'])
        style.configure('HS4.TLabel', font=(BODY_FONT, -16), foreground=custom_colours['primary'], 
                        background=custom_colours['secondary'])
        style.configure('HS5.TLabel', font=(HEADING_FONT, -14), foreground=custom_colours['primary'], 
                        background=custom_colours['secondary'])

    #----------------------------------------------------------------------------
        # Heading 4 (Comboboxes)
        style.configure('H4.TCombobox', font=(BODY_FONT, -16))

        # Combobox styling overrides (had to google)
        style.map('H4.TCombobox', # State Maps: explicitly override operating system states to ensure it preserves the custom colours
            fieldbackground=[('readonly', custom_colours['light']), ('disabled', custom_colours['light'])],
            foreground=[('readonly', custom_colours['fg']), ('disabled', custom_colours['fg'])],
            selectbackground=[('readonly', custom_colours['light'])], 
            selectforeground=[('readonly', custom_colours['fg'])])
        # Dropdown colour overrides
        self.option_add('*TCombobox*Listbox.font', (BODY_FONT, -16)) # Change the dropdown list font to match the combobox design
        def on_dropdown_popdown(event): # Register a class binding for every Combobox that manually forces the inner sub-listbox to accept custom colours
            popdown = event.widget.tk.call('ttk::combobox::PopdownWindow', event.widget) # !!!
            listbox = popdown + '.f.l'
            # Directly configure the underlying Tk graphic properties
            event.widget.tk.call(listbox, 'configure', '-background', custom_colours['light']) # Background color of the open dropdown menu list
            event.widget.tk.call(listbox, 'configure', '-foreground', custom_colours['primary']) # Text color of the unselected options inside the dropdown menu list
            event.widget.tk.call(listbox, 'configure', '-selectbackground', custom_colours['secondary']) # Highlight background color when you hover or arrow key down over an item
            event.widget.tk.call(listbox, 'configure', '-selectforeground', custom_colours['primary']) # Text color of the currently highlighted/selected option item
        self.bind_class('TCombobox', '<Map>', on_dropdown_popdown)  

    #---------------------------------------------------------------------------

        style.configure("Card.TFrame", background=style.colors.secondary, borderwidth=1, relief="solid")

    #---------------------------------------------------------------------------
        
        # Create a custom notebook style targeting the bottom orientation of the notebook
        style.configure('bottomtab.TNotebook', 
                        background=custom_colours['bg'], 
                        tabposition='s',
                        borderwidth=0,
                        highlightthickness=0,
                        lightcolor=custom_colours['bg'],
                        darkcolor=custom_colours['bg'],
                        bordercolor=custom_colours['bg']
                        )
        
        style.layout('bottomtab.TNotebook.Tab', [
            ('Notebook.tab', {'sticky': 'nswe', 'children': [
                ('Notebook.padding', {'side': 'top', 'sticky': 'nswe', 'children': [
                    ('Notebook.label', {'side': 'top', 'sticky': ''})
                ]})
            ]})
        ])
        
        # Style the tab header buttons at the bottom
        style.configure('bottomtab.TNotebook.Tab', 
                        background=custom_colours['secondary'], 
                        foreground=custom_colours['primary'], 
                        padding=[15, 6], 
                        font=(BODY_FONT, 10, 'bold'),
                        borderwidth=0,
                        focuscolor=custom_colours['bg'],
                        bordercolor=custom_colours['bg'])
        
        # Preserve color map changes for the bottom tab headers
        style.map('bottomtab.TNotebook.Tab', 
                    background=[
                    ('selected', custom_colours['primary']), 
                    ('active', custom_colours['active'])
                ], 
                foreground=[
                    ('selected', custom_colours['light']), 
                    ('active', custom_colours['fg'])
                ],
                bordercolor=[
                    ('selected', custom_colours['bg']),
                    ('active', custom_colours['bg']),
                    ('focus', custom_colours['bg'])
                ],
                lightcolor=[
                    ('selected', custom_colours['bg']),
                    ('focus', custom_colours['bg'])
                ],
                darkcolor=[
                    ('selected', custom_colours['bg']),
                    ('focus', custom_colours['bg'])
                ])

    #------------------------------------------------------------------------------

    def show_screen(self, screen_class): # Replace the current screen with a new screen
        if self.current_screen is not None:
            self.current_screen.destroy()
        self.current_screen = screen_class(self.container, self)
        self.current_screen.pack(fill="both", expand=True)

    '''def show_home(self): # Display the home screen
        if self.current_screen is not None:
            self.current_screen.destroy() # Destroy the current screen before loading the new one to ensure only one screen is visible at a time
        self.current_screen = HomeScreen(self.container, self)
        self.current_screen.pack(fill="both", expand=True)

    #----------------------------------------------------------------------------

    def show_case_one(self):
        if self.current_screen is not None:
            self.current_screen.destroy()
        self.current_screen = ChallengeScreenOne(self.container, self)
        self.current_screen.pack(fill="both", expand=True)'''

    #----------------------------------------------------------------------------

    '''def get_current_username(self): # Return the currently signed in username. Returns: str: The current username, or "Guest" if no user is signed in.
        return getattr(self, "current_user", "Guest") or "Guest"'''
    def get_current_username(self): # Return the currently signed-in username, or None for a guest
        return self.current_user

    #----------------------------------------------------------------------------

    def run(self):# Method for mainloop
        self.mainloop()

