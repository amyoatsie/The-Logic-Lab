import csv
from datetime import datetime
from pathlib import Path

class ChallengeEvaluator:
    def __init__(self, csv_path):
        self.csv_path = csv_path

        # Correct answers for case 1
        self.correct_answers = {
            "q1": "Image editing", 
            "q2": "Middle",
            "q3": "Image to File Data", 
            "q4": "Pink & Blue"}
        
        # Ensure the CSV file and its headers exist upon initialisation ???
        self._initialise_csv()

    def _initialise_csv(self): # Create the progress file with system headers if it does not exist yet."""
        path = Path(self.csv_path)
        # Ensure the parent data directory exists
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if not path.exists():
            with open(path, mode="w", newline="", encoding="utf-8") as file:
                writer = csv.writer(file)
                writer.writerow(["username", "timestamp", "currentChallenge", "numberCorrect", "questionNumber", "result"]) # change result to status?

    def validate_inputs(self, user_answers: dict) -> tuple[bool, str]:
        # Validate if the user completed all choices. Return a tuple: (True/False, 'Error message string')
        for key, value in user_answers.items(): # If the user hasn't selected anything return an empty string
            if not value or value.strip() == "":
                return False, "Please answer all questions before submitting!"
        return True, None

    def evaluate_answers(self, selections):
        correct_count = 0
        total_questions = len(self.correct_answers)
        results_breakdown = {}

        for key, correct_val in self.correct_answers.items():
            user_val = selections.get(key, "")
            is_correct = (user_val == correct_val)
            
            if is_correct:
                correct_count += 1
                
            results_breakdown[key] = is_correct

        # Define the passing status (must get all correct)
        passed = correct_count == total_questions

        return {
            "score": correct_count,
            "total": total_questions,
            "breakdown": results_breakdown,
            "passed": passed}

    def save_progress(self, username: str, challenge_name: str, score: int, total: int, passed: bool):
        """Reads the CSV file, updates the row matching username + challenge, or appends a new one."""
        self._initialise_csv()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status = "Pass" if passed else "Fail"
        
        updated_rows = []
        record_found = False
        headers = []

        # Read existing spreadsheet details into system memory
        with open(self.csv_path, mode="r", newline="", encoding="utf-8") as file:
            reader = csv.reader(file)
            headers = next(reader)  # Capture the column header layout
            clean_username = username.strip().lower()
            
            for row in reader:
                if not row:  # Safety check for blank rows
                    continue
                
                # Normalise the existing CSV row username to lower case for comparison
                existing_user = row[0].strip().lower() # maybe redundant
                
                # Check match against clean inputs
                if existing_user == clean_username and row[2] == challenge_name:
                    # Save the lowercase username to the CSV file
                    updated_rows.append([clean_username, timestamp, challenge_name, score, total, status])
                    record_found = True
                else:
                    updated_rows.append(row)

        # 2. If the user hasn't attempted this case before, append their new record
        if not record_found:
            updated_rows.append([username, timestamp, challenge_name, score, total, status])

        # Rewrite the CSV using write mode to delete old records out
        with open(self.csv_path, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(headers)       # Re-insert structure fields
            writer.writerows(updated_rows) # Save full updated data set

        '''# Append a new entry row to the file
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        status = "Pass" if passed else "Fail"
        
        with open(self.csv_path, mode="a", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow([username, timestamp, challenge_name, score, total, status])'''
