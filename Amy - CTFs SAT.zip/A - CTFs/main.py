from app import App # Import the app class itself

def main():
    app = App()
    app.mainloop() # Call the in-built mainloop engine :)

if __name__ == "__main__":
    main()

# NOTHING more needs to be added to this section
# NOTES -> could add a notebook section for notes which is written & read to a csv throughout each
# NOTES -> move username storage to app class cause screen classes should just be navigation and layout !!!